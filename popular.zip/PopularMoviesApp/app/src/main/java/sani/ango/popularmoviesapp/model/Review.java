/*In the name of Allah*/
package sani.ango.popularmoviesapp.model;

public class Review {
    private String review;
    private String author;

    public Review(String user, String comments){
        review = comments;
        author = user;
    }


    public String getReview() {
        return review;
    }

    public String getAuthor() {
        return author;
    }
}
